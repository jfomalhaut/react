import React from 'react';

const Home = () => {
	return (
		<h1>Home Component</h1>
	);
};

export default Home;
