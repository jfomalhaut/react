const imageURI = {
	meat1: require ('../../assets/meat1.jpg').default,
	meat2: require ('../../assets/meat2.jpg').default,
	meat3: require ('../../assets/meat3.jpg').default,
	meat4: require ('../../assets/meat4.jpg').default,
	meat5: require ('../../assets/meat5.jpg').default,
	meat6: require ('../../assets/meat6.jpg').default,
	meat7: require ('../../assets/meat7.jpg').default,
	meat8: require ('../../assets/meat8.jpg').default,
	meat9: require ('../../assets/meat9.jpg').default,
	meat10: require ('../../assets/meat10.jpg').default
};

export default imageURI;