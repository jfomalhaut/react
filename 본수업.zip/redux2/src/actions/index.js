import cartAction from './cartAction';

const Actions = {
	cartAction
};

export default Actions;