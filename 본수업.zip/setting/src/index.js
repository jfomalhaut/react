import React from 'react';
import ReactDOM from 'react-dom';

ReactDOM.render(<button>나는 버튼</button>, document.getElementById('root'));