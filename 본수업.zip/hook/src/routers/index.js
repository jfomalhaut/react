import Corona from './Corona';
import Input from './Input';
import Input2 from './Input2';
import List from './List';
import Method from './Method';

export {
	Corona, Input, Input2, List, Method
};