import Card from './Card';
import Card2 from './Card2';

export {
	Card, Card2
};
